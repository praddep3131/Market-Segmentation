# Market-Segmentation
The code is designed to run on Google Colab, which provides all the necessary libraries pre-installed. If you run this locally, ensure you have the following Python libraries:
NumPy
Pandas
Matplotlib
Contributions
Contributions are welcome! Please fork the repository and submit a pull request for any improvements or additional features.
